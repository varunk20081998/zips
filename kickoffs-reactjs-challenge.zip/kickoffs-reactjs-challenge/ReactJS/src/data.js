export const events=[
    {
        name:"Modern Web Development",
        description:"This session will cover the technologies that is being used to develop mordern webapp",
        date: new Date(),
        time:"3.00 PM",
        duration:"1 hr",
        mode:"Online",
        attendees:[]
    },
    {
        name:"Wings",
        description:"This session will cover structure of upcoming wings assessment",
        date: new Date(),
        time:"5.00 PM",
        duration:"1 hr",
        mode:"Online Or Offline",
        location:"XYZ",
        branch:"abcdef",
        attendees:[]
    },
    {
        name:"Design Thinking",
        description:"Register here to connect with expects to get to know more about design thinking",
        date: new Date(),
        time:"11.00 AM",
        duration:"1 hr",
        mode:"Offline",
        location:"XYZ",
        branch:"abcdef",
        attendees:[]
    }
]