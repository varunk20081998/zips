import React from "react";


function Modal(props) {
    return (
        <>
            <div id="Modal" className="ModalBg" />
            <div className="Pop">
                <span>Attendees</span>
                <hr></hr>
                <table>
                    <thead>
                        {/*code goes here*/}
                    </thead>
                    <tbody>
                        {/*code goes here*/}
                    </tbody>
                </table>
                <button id="cancel">Close</button>
            </div>
        </>
    );
}

export default Modal;

