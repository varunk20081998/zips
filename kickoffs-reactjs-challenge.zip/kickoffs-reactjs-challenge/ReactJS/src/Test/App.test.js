import React from 'react';
import { configure, shallow } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
configure({ adapter: new Adapter() })
import App from '../App';
import { events } from "../data";

const option = ["Select Event Name", "Modern Web Development", "Wings", "Design Thinking"]

const handleDate = (date) => {
  const getDate = new Date(date).getDate()
  const getMonth = new Date(date).getMonth()
  const getYear = new Date(date).getFullYear()
  return `${getDate}/${getMonth + 1}/${getYear}`
}
test('Initial rendering of aside', () => {
  const Component = shallow(<App />)
  const aside = Component.find("aside")
  expect(aside.find("h1").at(0).text()).toBe("Register For An Events")
  expect(aside.find("input").at(0).props().placeholder).toBe("Your Name")
  expect(aside.find("input").at(1).props().placeholder).toBe("Your Email ID")
  expect(aside.find("input").at(0).props().value).toBe("")
  expect(aside.find("input").at(1).props().value).toBe("")
  expect(aside.find("select").props().value).toBe("")
  expect(aside.find("select").find("option").at(0).props().value).toBe("")
  for (let index = 0; index < option.length; index++) {
    expect(aside.find("select").find("option").at(index).text()).toBe(option[index])
  }
  expect(Component.find("label").length).toBe(0);
  expect(Component.find("h3").length).toBe(0)
  expect(Component.find(".detailsDiv").length).toBe(0)
  expect(Component.find("h1").at(1).text()).toBe("Please Select An Event Name")
  expect(Component.find("button").length).toBe(0)
})

test('Initial rendering of Events List', () => {
  const Component = shallow(<App />)
  const section = Component.find("section")
  expect(section.find("h1").at(0).text()).toBe("Events List")
  for (let index = 0; index < events.length; index++) {
    expect(section.find(".eventCard").at(index).find(".attendees div").at(0).text()).toBe("No. Of Attendees")
    expect(section.find(".eventCard").at(index).find(".attendees div").at(1).text()).toBe("0")
    expect(section.find(".eventCard").at(index).find("div table tr").at(0).find("td").text()).toBe(events[index].name)
    expect(section.find(".eventCard").at(index).find("div table tr").at(1).find("td").text()).toBe(events[index].description)
    expect(section.find(".eventCard").at(index).find("div table tr").at(2).find("td").at(0).text()).toBe(`Date: ${handleDate(events[index].date)}`)
    expect(section.find(".eventCard").at(index).find("div table tr").at(2).find("td").at(1).text()).toBe(`Time: ${events[index].time}`)
    expect(section.find(".eventCard").at(index).find("div table tr").at(3).find("td").at(0).text()).toBe(`Duration: ${events[index].duration}`)
    expect(section.find(".eventCard").at(index).find("div table tr").at(3).find("td").at(1).text()).toBe(`Mode: ${events[index].mode}`)
  }
})

test('On Selecting Events', () => {
  const Component = shallow(<App />)
  const aside = Component.find("aside")
  aside.find("select").simulate('change', { target: { value: "Modern Web Development" } })
  expect(Component.find("aside h3").text()).toBe("Event Details")
  expect(Component.find("aside div table tr").at(0).find("td").text()).toBe("Modern Web Development")
  expect(Component.find("aside div table tr").at(1).find("td").text()).toBe("This session will cover the technologies that is being used to develop mordern webapp")
  expect(Component.find("aside div table tr").at(2).find("td").at(0).text()).toBe(`Date: ${handleDate(events[0].date)}`)
  expect(Component.find("aside div table tr").at(2).find("td").at(1).text()).toBe(`Time: ${events[0].time}`)
  expect(Component.find("aside div table tr").at(3).find("td").at(0).text()).toBe(`Duration: ${events[0].duration}`)
  expect(Component.find("aside div table tr").at(3).find("td").at(1).text()).toBe(`Mode: ${events[0].mode}`)
  expect(Component.find("aside div table tr").at(4).find("td").text()).toBe(`Event link will be sent to your email`)


  aside.find("select").simulate('change', { target: { value: "Wings" } })
  expect(Component.find("aside div table tr").at(0).find("td").text()).toBe("Wings")
  expect(Component.find("aside div table tr").at(1).find("td").text()).toBe("This session will cover structure of upcoming wings assessment")
  expect(Component.find("aside div table tr").at(2).find("td").at(0).text()).toBe(`Date: ${handleDate(events[1].date)}`)
  expect(Component.find("aside div table tr").at(2).find("td").at(1).text()).toBe(`Time: ${events[1].time}`)
  expect(Component.find("aside div table tr").at(3).find("td").at(0).text()).toBe(`Duration: ${events[1].duration}`)
  expect(Component.find("aside div table tr").at(3).find("td").at(1).text()).toBe(`Mode: ${events[1].mode}`)
  expect(Component.find("aside div table tr").at(4).find("td").at(0).text()).toBe(`Location: ${events[1].location}`)
  expect(Component.find("aside div table tr").at(4).find("td").at(1).text()).toBe(`Branch: ${events[1].branch}`)
  expect(Component.find("label").at(0).text()).toBe("Choose The Mode")
  expect(Component.find("aside").find("div").at(0).find("input").at(0).props().checked).toBe(false)
  expect(Component.find("aside").find("div").at(0).find("input").at(1).props().checked).toBe(true)
  Component.find("aside").find("div").at(0).find("input").at(0).simulate('change')
  expect(Component.find("aside").find("div").at(0).find("input").at(0).props().checked).toBe(true)
  expect(Component.find("aside").find("div").at(0).find("input").at(1).props().checked).toBe(false)
  expect(Component.find("aside div table tr").at(4).find("td").text()).toBe(`Event link will be sent to your email`)

  aside.find("select").simulate('change', { target: { value: "Design Thinking" } })
  expect(Component.find("aside div table tr").at(0).find("td").text()).toBe("Design Thinking")
  expect(Component.find("aside div table tr").at(1).find("td").text()).toBe("Register here to connect with expects to get to know more about design thinking")
  expect(Component.find("aside div table tr").at(2).find("td").at(0).text()).toBe(`Date: ${handleDate(events[2].date)}`)
  expect(Component.find("aside div table tr").at(2).find("td").at(1).text()).toBe(`Time: ${events[2].time}`)
  expect(Component.find("aside div table tr").at(3).find("td").at(0).text()).toBe(`Duration: ${events[2].duration}`)
  expect(Component.find("aside div table tr").at(3).find("td").at(1).text()).toBe(`Mode: ${events[2].mode}`)
  expect(Component.find("aside div table tr").at(4).find("td").at(0).text()).toBe(`Location: ${events[2].location}`)
  expect(Component.find("aside div table tr").at(4).find("td").at(1).text()).toBe(`Branch: ${events[2].branch}`)
  expect(Component.find("aside").find("div").at(0).find("input").at(0).length).toBe(0)
})

test('Register-invalid', () => {
  const Component = shallow(<App />)
  const aside = Component.find("aside")
  aside.find("input").at(0).simulate("change", { target: { value: "An" } })
  aside.find("select").simulate('change', { target: { value: "Design Thinking" } })
  Component.find("aside div button").simulate('click')
  expect(Component.find("aside div p").text()).toBe("Name inputfield value expects minimum of three characters which includes letters and spaces only, Please enter your email in format: yourname@example.com")
  aside.find("input").at(0).simulate("change", { target: { value: "Anusha" } })
  aside.find("input").at(1).simulate("change", { target: { value: "    " } })
  Component.find("aside div button").simulate('click')
  expect(Component.find("aside div p").text()).toBe("Please enter your email in format: yourname@example.com")
  aside.find("input").at(1).simulate("change", { target: { value: "an.com" } })
  Component.find("aside div button").simulate('click')
  expect(Component.find("aside div p").text()).toBe("Please enter your email in format: yourname@example.com")
  aside.find("input").at(1).simulate("change", { target: { value: "anu@gmail.com" } })
  Component.find("aside div button").simulate('click')
})


test('Register-valid', async () => {
  const Component = shallow(<App />)
  await Component.find("aside").find("input").at(1).simulate("change", { target: { value: "tara@gmail.com" } })
  await Component.find("aside").find("input").at(0).simulate("change", { target: { value: "tara" } })
  await Component.find("aside").find("select").simulate('change', { target: { value: "Wings" } })
  expect(Component.find("aside div button").text()).toBe("Register")
  await Component.find("aside div button").simulate('click')

  expect(Component.find(".eventCard").at(1).find(".attendees div").at(0).text()).toBe("No. Of Attendees")
  expect(Component.find(".eventCard").at(1).find(".attendees div").at(1).text()).toBe("1")

  await Component.find("aside").find("input").at(1).simulate("change", { target: { value: "Clara@gmail.com" } })
  await Component.find("aside").find("input").at(0).simulate("change", { target: { value: "Clara" } })
  await Component.find("aside").find("select").simulate('change', { target: { value: "Wings" } })
  await Component.find("aside").find("div").at(0).find('input').at(0).simulate('change')
  expect(Component.find("aside div button").text()).toBe("Register")
  await Component.find("aside div button").simulate('click')

  expect(Component.find(".eventCard").at(1).find(".attendees div").at(0).text()).toBe("No. Of Attendees")
  expect(Component.find(".eventCard").at(1).find(".attendees div").at(1).text()).toBe("2")

  expect(Component.find(".eventCard").at(0).find(".attendees div").at(0).text()).toBe("No. Of Attendees")
  expect(Component.find(".eventCard").at(0).find(".attendees div").at(1).text()).toBe("0")

  expect(Component.find(".eventCard").at(2).find(".attendees div").at(0).text()).toBe("No. Of Attendees")
  expect(Component.find(".eventCard").at(2).find(".attendees div").at(1).text()).toBe("0")

  await Component.find("aside").find("input").at(1).simulate("change", { target: { value: "anu@gmail.com" } })
  await Component.find("aside").find("input").at(0).simulate("change", { target: { value: "anu" } })
  await Component.find("aside").find("select").simulate('change', { target: { value: "Design Thinking" } })
  expect(Component.find("aside div button").text()).toBe("Register")
  await Component.find("aside div button").simulate('click')

  expect(Component.find(".eventCard").at(2).find(".attendees div").at(1).text()).toBe("1")
})

test('Display - Modal', async () => {
  const Component = shallow(<App />)
  expect(Component.find("Modal").length).toBe(0)
  Component.find(".eventCard").at(1).find(".attendees").simulate("click")
  expect(Component.find("Modal").length).toBe(1)
})
