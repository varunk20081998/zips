import React from 'react';
import { configure, shallow } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
configure({ adapter: new Adapter() })
import Modal from '../Component/Modal';

const event1 = {
    name: "Modern Web Development",
    description: "This session will cover the technologies that is being used to develop mordern webapp",
    date: new Date(),
    time: "3.00 PM",
    duration: "1 hr",
    mode: "Online",
    attendees: [
        {
            email: "anu@gmail.com",
            mode: "Offline",
            name: "Anusha"
        },
        {
            email: "tara@gmail.com",
            mode: "Offline",
            name: "Tara"
        }
    ]
}

const event2 = {
    name: "Modern Web Development",
    description: "This session will cover the technologies that is being used to develop mordern webapp",
    date: new Date(),
    time: "3.00 PM",
    duration: "1 hr",
    mode: "Online Or Offline",
    attendees: [
        {
            email: "anu@gmail.com",
            mode: "Offline",
            name: "Anusha"
        },
        {
            email: "tara@gmail.com",
            mode: "Online",
            name: "Tara"
        }
    ]
}

test('No Attendees', () => {
    const Component = shallow(<Modal attendeesList={[]} />)
    expect(Component.find(".Pop span").text()).toBe("Attendees")
    expect(Component.find("table thead tr th").at(0).text()).toBe("Sl. No")
    expect(Component.find("table thead tr th").at(1).text()).toBe("Name")
    expect(Component.find("table thead tr th").at(2).text()).toBe("Email")
    expect(Component.find("table thead tr th").length).toBe(3)

    expect(Component.find(".Pop span").text()).toBe("Attendees")
    expect(Component.find("table tbody tr td").text()).toBe("No Attendees")
})

test('Attendees List-1', () => {
    const Component = shallow(<Modal attendeesList={event1} />)
    expect(Component.find(".Pop span").text()).toBe("Attendees")
    expect(Component.find("table tbody tr").at(0).find("td").at(0).text()).toBe("1.")
    expect(Component.find("table tbody tr").at(0).find("td").at(1).text()).toBe("Anusha")
    expect(Component.find("table tbody tr").at(0).find("td").at(2).text()).toBe("anu@gmail.com")
    expect(Component.find("table tbody tr").at(0).find("td").length).toBe(3)
    expect(Component.find("table thead tr th").length).toBe(3)

    expect(Component.find("table tbody tr").at(1).find("td").at(0).text()).toBe("2.")
    expect(Component.find("table tbody tr").at(1).find("td").at(1).text()).toBe("Tara")
    expect(Component.find("table tbody tr").at(1).find("td").at(2).text()).toBe("tara@gmail.com")
    expect(Component.find("table tbody tr").at(1).find("td").length).toBe(3)
})

test('Attendees List-2', () => {
    const Component = shallow(<Modal attendeesList={event2} />)
    expect(Component.find(".Pop span").text()).toBe("Attendees")
    expect(Component.find("table tbody tr").at(0).find("td").at(0).text()).toBe("1.")
    expect(Component.find("table tbody tr").at(0).find("td").at(1).text()).toBe("Anusha")
    expect(Component.find("table tbody tr").at(0).find("td").at(2).text()).toBe("anu@gmail.com")
    expect(Component.find("table tbody tr").at(0).find("td").length).toBe(4)
    expect(Component.find("table thead tr th").length).toBe(4)
    expect(Component.find("table tbody tr").at(0).find("td").at(3).text()).toBe("Offline")

    expect(Component.find("table tbody tr").at(1).find("td").at(0).text()).toBe("2.")
    expect(Component.find("table tbody tr").at(1).find("td").at(1).text()).toBe("Tara")
    expect(Component.find("table tbody tr").at(1).find("td").at(2).text()).toBe("tara@gmail.com")
    expect(Component.find("table tbody tr").at(1).find("td").length).toBe(4)
    expect(Component.find("table tbody tr").at(1).find("td").at(3).text()).toBe("Online")
})

