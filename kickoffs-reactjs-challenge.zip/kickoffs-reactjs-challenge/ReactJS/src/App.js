import "./App.css";
import Modal from "./Component/Modal";
import { events } from "./data";
import { useState } from "react";

function App() {
  // error messages
  // for name -> Name inputfield value expects minimum of three characters which includes letters and spaces only
  // for email -> "Please enter your email in format: yourname@example.com
  const [mode, setMode] = useState(false);
  const [eventMode, setEventMode] = useState(false);
  const [eventData] = useState(events);
  const [data, setData] = useState({});
  const [radio, setRadio] = useState(false);
  const handleRadio=(e)=>{
    // console.log(e.target.value);
    setRadio(!radio)
  }

 
  const handleDate = (date) => {
    const getDate = new Date(date).getDate();
    const getMonth = new Date(date).getMonth();
    const getYear = new Date(date).getFullYear();
    return `${getDate}/${getMonth + 1}/${getYear}`;
  };
  const handleSelect = (e) => {
    // seting radio button state
    let event = e.target.value;
    let got = eventData.filter((x) => x.name === event);

    if (got) {
      if (got[0].mode === "Online Or Offline") {
        setMode(true);
      }
      setData(got[0]);
    }
    setEventMode(true);
  };

  return (
    <div>
      <div className="App">
        <aside>
          <h1>Register For An Events</h1>
          <input type="text" name="name" placeholder="Your Name" value="" />
          <input
            type="email"
            name="email"
            placeholder="Your Email ID"
            value=""
          />
          <select value="" onChange={handleSelect}>
            <option value="" selected hidden>
              Select Event Name
            </option>
            {events.map((item, idex) => (
              <option key={idex} value={item.name}>
                {item.name}
              </option>
            ))}
          </select>
          {mode && (
            <div style={{ flexDirection: "column", color: "white" }}>
              <label>Choose The Mode</label>
             
              <input
                type="radio"
                name="mode"
                value="offline"
                id="myRadio"
                onChange={handleRadio}
                checked={radio}
              />
              offline
              <input
                type="radio"
                name="mode"
                value="online"
                id="myRadio2"
                onChange={handleRadio}
                checked={!radio}
              />
              online
            </div>
          )}
          

          {
            /* Event details goes here*/
            eventMode && (
              <>
                <h3>Event Details</h3>
                <div>
                  <table className="detailsDiv" width="100%">
                    {/* Display event details here*/}
                    <tr>
                      <td>{data.name}</td>
                    </tr>
                    <tr>
                      <td>{data.description}</td>
                    </tr>
                    <tr>
                      <td>Date: {handleDate(data.date)}</td>
                      <td>Time: {data.time}</td>
                    </tr>
                    <tr>
                      <td>Duration: {data.duration}</td>
                      <td>Mode: {data.mode}</td>
                    </tr>
                    {data.location && data.branch && (
                      <tr>
                        <td>Location: {data.location}</td>
                        <td>Branch: {data.branch}</td>
                      </tr>
                    )}
                    <tr>
                      <td>Event link will be sent to your email</td>
                    </tr>
                  </table>
                  <p className="error"></p>
                  <button type="submit">Register</button>
                </div>
              </>
            )
          }

          <div>
            <h1>Please Select An Event Name</h1>
          </div>
        </aside>
        <section>
          {/* <div key={i} className='eventCard'>
                <div className="attendees" onClick={() => handleModal(event)}>
                  
                </div>
                <div>
                  <table className='eventDetails'>
                    code goes here for 
                  </table>
                </div>
              </div> */}
        </section>
      </div>
      {/* <Modal /> */}
    </div>
  );
}

export default App;
